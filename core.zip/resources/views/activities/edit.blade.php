<x-app-layout>
    <x-slot name="header"><h1 class="text-xl font-semibold text-gray-800">แก้ไขกิจกรรม</h1></x-slot>
    <div class="flex items-center gap-2 text-sm text-gray-500 mb-6"><a href="{{ route('activities.index') }}" class="hover:text-navy-600">จัดคิวกิจกรรม</a><i data-lucide="chevron-right" class="w-4 h-4"></i><span class="text-gray-800">แก้ไข</span></div>
    <div class="card max-w-4xl"><div class="card-header"><h3 class="text-lg font-semibold text-gray-800">แก้ไขข้อมูลกิจกรรม</h3></div><div class="card-body"><form action="{{ route('activities.update', $activity) }}" method="POST">@csrf @method('PUT')<div class="grid grid-cols-1 md:grid-cols-2 gap-6"><div class="md:col-span-2"><label class="block text-sm font-medium text-gray-700 mb-2">ชื่อกิจกรรม <span class="text-red-500">*</span></label><input type="text" name="activity_name" value="{{ old('activity_name', $activity->activity_name) }}" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg" required></div><div><label class="block text-sm font-medium text-gray-700 mb-2">วันที่เริ่ม <span class="text-red-500">*</span></label><input type="date" name="start_date" value="{{ old('start_date', $activity->start_date?->format('Y-m-d')) }}" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg" required></div><div><label class="block text-sm font-medium text-gray-700 mb-2">วันที่สิ้นสุด</label><input type="date" name="end_date" value="{{ old('end_date', $activity->end_date?->format('Y-m-d')) }}" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg"></div><div><label class="block text-sm font-medium text-gray-700 mb-2">เวลาเริ่ม</label><input type="time" name="start_time" value="{{ old('start_time', $activity->start_time) }}" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg"></div><div><label class="block text-sm font-medium text-gray-700 mb-2">เวลาสิ้นสุด</label><input type="time" name="end_time" value="{{ old('end_time', $activity->end_time) }}" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg"></div><div><label class="block text-sm font-medium text-gray-700 mb-2">สถานที่</label><input type="text" name="location" value="{{ old('location', $activity->location) }}" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg"></div><div><label class="block text-sm font-medium text-gray-700 mb-2">สถานะ <span class="text-red-500">*</span></label><select name="status" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg" required><option value="pending" {{ old('status', $activity->status) == 'pending' ? 'selected' : '' }}>รอดำเนินการ</option><option value="ongoing" {{ old('status', $activity->status) == 'ongoing' ? 'selected' : '' }}>กำลังดำเนินการ</option><option value="completed" {{ old('status', $activity->status) == 'completed' ? 'selected' : '' }}>เสร็จสิ้น</option><option value="cancelled" {{ old('status', $activity->status) == 'cancelled' ? 'selected' : '' }}>ยกเลิก</option></select></div><div><label class="block text-sm font-medium text-gray-700 mb-2">ความสำคัญ (1-5) <span class="text-red-500">*</span></label><select name="priority" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg" required>@for($i = 1; $i <= 5; $i++)<option value="{{ $i }}" {{ old('priority', $activity->priority) == $i ? 'selected' : '' }}>{{ $i }}{{ $i == 1 ? ' - ต่ำ' : ($i == 3 ? ' - ปานกลาง' : ($i == 5 ? ' - สูง' : '')) }}</option>@endfor</select></div>
    
    <div class="md:col-span-2" x-data="{ search: '' }">
        <label class="block text-sm font-medium text-gray-700 mb-2">ผู้เข้าร่วมกิจกรรม</label>
        <div class="border border-gray-300 rounded-lg overflow-hidden">
            <div class="p-2 border-b border-gray-200 bg-gray-50">
                <input type="text" x-model="search" placeholder="ค้นหาชื่อ..." class="w-full px-3 py-1.5 text-sm border border-gray-300 rounded-md focus:ring-navy-500 focus:border-navy-500">
            </div>
            <div class="max-h-48 overflow-y-auto p-2 space-y-1">
                @foreach($personnel as $person)
                <label class="flex items-center gap-2 px-2 py-1.5 hover:bg-gray-50 rounded cursor-pointer" x-show="'{{ $person->first_name }} {{ $person->last_name }}'.toLowerCase().includes(search.toLowerCase())">
                    <input type="checkbox" name="participants[]" value="{{ $person->id }}" 
                           {{ $activity->participants->contains($person->id) ? 'checked' : '' }}
                           class="rounded text-navy-600 focus:ring-navy-500 border-gray-300">
                    <span class="text-sm text-gray-700">{{ $person->rank }} {{ $person->first_name }} {{ $person->last_name }}</span>
                    <span class="text-xs text-gray-400 ml-auto">{{ $person->position }}</span>
                </label>
                @endforeach
            </div>
            <div class="p-2 bg-gray-50 border-t border-gray-200 text-xs text-gray-500">
                เลือกผู้เข้าร่วมกิจกรรมโดยการติ๊กถูก
            </div>
        </div>
    </div>
    
    <div class="md:col-span-2"><label class="block text-sm font-medium text-gray-700 mb-2">รายละเอียด</label><textarea name="description" rows="4" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg">{{ old('description', $activity->description) }}</textarea></div></div><div class="flex items-center justify-end gap-3 mt-8 pt-6 border-t border-gray-200"><a href="{{ route('activities.index') }}" class="px-6 py-2.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium">ยกเลิก</a><button type="submit" class="inline-flex items-center gap-2 px-6 py-2.5 bg-navy-700 text-white rounded-lg hover:bg-navy-800 font-medium"><i data-lucide="save" class="w-5 h-5"></i>บันทึก</button></div></form></div></div>
</x-app-layout>
