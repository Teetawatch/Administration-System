<x-app-layout>
    <x-slot name="header"><h1 class="text-xl font-semibold text-gray-800">แก้ไขข่าวราชนาวี</h1></x-slot>
    <div class="flex items-center gap-2 text-sm text-gray-500 mb-6">
        <a href="{{ route('navy-news.index') }}" class="hover:text-navy-600">ข่าวราชนาวี</a>
        <i data-lucide="chevron-right" class="w-4 h-4"></i><span class="text-gray-800">แก้ไข</span>
    </div>
    <div class="card max-w-4xl">
        <div class="card-header"><h3 class="text-lg font-semibold text-gray-800">แก้ไขข้อมูลข่าว</h3></div>
        <div class="card-body">
            <form action="{{ route('navy-news.update', $navyNews) }}" method="POST" enctype="multipart/form-data">
                @csrf @method('PUT')
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div><label class="block text-sm font-medium text-gray-700 mb-2">เลขที่ข่าว <span class="text-red-500">*</span></label><input type="text" name="news_number" value="{{ old('news_number', $navyNews->news_number) }}" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg" required></div>
                    <div><label class="block text-sm font-medium text-gray-700 mb-2">วันที่ <span class="text-red-500">*</span></label><input type="date" name="news_date" value="{{ old('news_date', $navyNews->news_date?->format('Y-m-d')) }}" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg" required></div>
                    <div class="md:col-span-2"><label class="block text-sm font-medium text-gray-700 mb-2">หัวข้อ <span class="text-red-500">*</span></label><input type="text" name="title" value="{{ old('title', $navyNews->title) }}" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg" required></div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">ชั้นความเร็ว <span class="text-red-500">*</span></label>
                        <select name="urgency" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500">
                            <option value="normal" {{ old('urgency', $navyNews->urgency) == 'normal' ? 'selected' : '' }}>ปกติ</option>
                            <option value="urgent" class="text-red-600 font-bold" {{ old('urgency', $navyNews->urgency) == 'urgent' ? 'selected' : '' }}>ด่วน</option>
                            <option value="very_urgent" class="text-red-600 font-bold" {{ old('urgency', $navyNews->urgency) == 'very_urgent' ? 'selected' : '' }}>ด่วนมาก</option>
                            <option value="most_urgent" class="text-red-600 font-bold" {{ old('urgency', $navyNews->urgency) == 'most_urgent' ? 'selected' : '' }}>ด่วนที่สุด</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">ไฟล์แนบ</label>
                        @if($navyNews->attachment_path)
                            <div class="mb-2 p-2 bg-gray-50 rounded flex items-center justify-between text-sm">
                                <span>ไฟล์ปัจจุบัน</span>
                                <a href="{{ Storage::url($navyNews->attachment_path) }}" target="_blank" class="text-navy-600 hover:text-navy-800 underline">ดูไฟล์</a>
                            </div>
                        @endif
                        <input type="file" name="attachment" class="w-full px-4 py-2 border border-gray-300 rounded-lg file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-navy-50 file:text-navy-700">
                    </div>
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-2">เนื้อหา</label>
                        <textarea name="content" rows="4" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-navy-500">{{ old('content', $navyNews->content) }}</textarea>
                    </div>
                </div>
                <div class="flex items-center justify-end gap-3 mt-8 pt-6 border-t border-gray-200">
                    <a href="{{ route('navy-news.index') }}" class="px-6 py-2.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium">ยกเลิก</a>
                    <button type="submit" class="inline-flex items-center gap-2 px-6 py-2.5 bg-navy-700 text-white rounded-lg hover:bg-navy-800 font-medium"><i data-lucide="save" class="w-5 h-5"></i>บันทึก</button>
                </div>
            </form>
        </div>
    </div>
</x-app-layout>
